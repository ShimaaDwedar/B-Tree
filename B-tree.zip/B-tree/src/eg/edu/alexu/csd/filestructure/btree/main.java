package eg.edu.alexu.csd.filestructure.btree;

import java.util.ArrayList;
import java.util.List;

public class main {

	public static void main(String[] args) {
		BTreeNode t = new BTreeNode();
	    List keys = new ArrayList();
	    keys.add(1);
	    keys.add(2);
	    keys.add(4);
	    t.setKeys(keys);
	    List children = new ArrayList();
	    BTreeNode cht = new BTreeNode();
	    List chkeys = new ArrayList();
	    chkeys.add(3);
	    chkeys.add(2);
	    chkeys.add(4);
	    cht.setKeys(chkeys);
	    children.add(cht);
	    t.setChildren(children);
	    IBTreeNode child = (IBTreeNode) t.getChildren().get(0);
		System.out.println(child.getKeys());

	}

}
