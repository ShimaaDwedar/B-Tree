package eg.edu.alexu.csd.filestructure.btree;

public class SearchResult implements ISearchResult {
	SearchResult(String s , int x){
		
	}
	
	@Override
	public String getId() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setId(String id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int getRank() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void setRank(int rank) {
		// TODO Auto-generated method stub
		
	}

}
