package eg.edu.alexu.csd.filestructure.btree;
 
import javax.management.RuntimeErrorException;
import java.util.ArrayList;
import java.util.List;
 
public class BTree <K extends Comparable<K>, V> implements IBTree {
	private IBTreeNode root;
	private int  minimumDegree;
	private int maxKeys;
	private int flag;
    private List<K> keys = new ArrayList<K>();
    private List<V> values = new ArrayList<V>();
    private List<IBTreeNode<K,V>> children = new ArrayList<IBTreeNode<K,V>>();
    private List<K> keys2 = new ArrayList<K>();
    private List<V> values2 = new ArrayList<V>();
    private List<IBTreeNode<K,V>> children2 = new ArrayList<IBTreeNode<K,V>>();
 
    BTree(int minimumDegree){
        if(minimumDegree<2)
            throw new RuntimeErrorException(null);
        this.minimumDegree=  minimumDegree;
        root=null;
        maxKeys = 2*minimumDegree - 1;
    }
 
    public void print(IBTreeNode<K, V> node, int j){
        System.out.println(j +":" +node.getKeys());
        j++;
        for(int i=0; i<node.getChildren().size(); i++)
            print(node.getChildren().get(i), j);
 
    }
 
	@Override
	public int getMinimumDegree() {
		return this.minimumDegree;
	}
 
	@Override
	public IBTreeNode getRoot() {
		if (root==null)
            return null;
        return root;
	}
 
	@Override
	public void insert(Comparable key, Object value) {
        if(key ==null || value == null)
            throw new RuntimeErrorException(null);
	    if (root==null) {
            root = new BTreeNode();
            keys.add((K) key);
            values.add((V) value);
            root.setKeys(keys);
            root.setValues(values);
            root.setNumOfKeys(1);
        }
	    else{
	        if(root.getNumOfKeys() == maxKeys)      //Full Node
	            InsertFull(root, key, value);
	        else
	            InsertNotFull(root, key, value);
        }
/*	    print(root, 0);
	    System.out.println("*******************");*/
	}
 
	private void InsertFull(IBTreeNode<K, V> root, Comparable key, Object value){
        root = Split(root, null, 0);
        if(key.compareTo(getRoot().getKeys().get(0))<0)
            InsertNotFull(root.getChildren().get(0), key, value);
        else
            InsertNotFull(root.getChildren().get(1), key, value);
    }
    private void InsertNotFull(IBTreeNode<K, V> node, Comparable key, Object value){
        clearAdded();
        keys2 = node.getKeys();
        values2 = node.getValues();
        int no = node.getNumOfKeys();
        int i = no-1;
        while (i >= 0 && key.compareTo(node.getKeys().get(i))<0)
            i--;
        if(node.isLeaf()){
            keys2.add(i+1, (K) key);
            values2.add(i+1, (V) value);
            node.setKeys(keys2);
            node.setValues(values2);
            node.setNumOfKeys(no+1);
        }
        else {
            IBTreeNode prev = node;
            IBTreeNode child = node.getChildren().get(i+1);
            if(child.getNumOfKeys() == maxKeys) {
                Split(child, prev, i + 1);
                if(key.compareTo(node.getKeys().get(i+1))<0)
                    child = node.getChildren().get(i+1);
                else
                    child = node.getChildren().get(i+2);
            }
            InsertNotFull(child, key, value);
        }
    }
    private void clearAdded(){
	    keys2 = new ArrayList<>();
	    values2 = new ArrayList<>();
	    children2 = new ArrayList<>();
    }
    private IBTreeNode Split(IBTreeNode node, IBTreeNode prev, int order){
	    flag = 0;
	    IBTreeNode left = new BTreeNode();
	    IBTreeNode right = new BTreeNode();
	    int no = node.getNumOfKeys();
        int mid = no/2;
        K midK = (K) node.getKeys().get(mid);
        V midV = (V) node.getValues().get(mid);
        getLRC(left, right, node, mid);
        clearAdded();
        if(prev == null){
            this.root = new BTreeNode();
            keys2.add(midK);
            values2.add(midV);
            children2.add(left);
            children2.add(right);
            this.root.setKeys(keys2);
            this.root.setValues(values2);
            this.root.setChildren(children2);
            this.root.setLeaf(false);
            this.root.setNumOfKeys(1);
            return root;
        }
        else {
            keys2 = prev.getKeys();
            values2 = prev.getValues();
            children2 = prev.getChildren();
            keys2.add(order, midK);
            values2.add(order, midV);
            children2.remove(order);
            children2.add(order, left);
            children2.add(order+1, right);
            prev.setKeys(keys2);
            prev.setValues(values2);
            prev.setChildren(children2);
            prev.setLeaf(false);
            prev.setNumOfKeys(keys2.size());
            return prev;
        }
    }
    private void getLRC(IBTreeNode left, IBTreeNode right, IBTreeNode node, int mid){
        keys = node.getKeys();
        values = node.getValues();
        children = node.getChildren();
        clearAdded();
        if(children.size()>0)
            flag = 1;
 
        for(int i=0; i<mid; i++){
            keys2.add(keys.get(i));
            values2.add(values.get(i));
            if(flag==1)
                children2.add(children.get(i));
        }
        if(flag==1)
            children2.add(children.get(mid));
 
        left.setKeys(keys2);
        left.setValues(values2);
        left.setChildren(children2);
        left.setNumOfKeys(keys2.size());
 
 
        clearAdded();
        for(int i = mid+1; i<node.getNumOfKeys(); i++){
            keys2.add(keys.get(i));
            values2.add(values.get(i));
            if(flag==1)
                children2.add(children.get(i));
        }
 
        right.setKeys(keys2);
        right.setValues(values2);
        right.setChildren(children2);
        right.setNumOfKeys(keys2.size());
        right.setLeaf(node.isLeaf());
 
    }

	@Override
	public Object search(Comparable key) {
		// TODO Auto-generated method stub
		if(key==null){
			throw new RuntimeErrorException(null);
		}
		if(root==null){
			return null;
		}
		else{
			IBTreeNode temp=root;
			while (!temp.isLeaf()){
				if(temp.getKeys().contains(key)){
					return temp.getValues().get(temp.getKeys().indexOf(key));
				}
				else {
					List keys =temp.getKeys();
					for (int i=0;i<keys.size();i++){
						if((key.compareTo(keys.get(i))<0)){
							temp=(IBTreeNode) temp.getChildren().get(i);
							break;
						}
						else if ((i==keys.size()-1)){
							temp=(IBTreeNode) temp.getChildren().get(i+1);
						}
					}
				}
			}
			if(temp.getKeys().contains(key)){
				return temp.getValues().get(temp.getKeys().indexOf(key));
			}
			else{
				return null;
			}
		}
	}

	@Override
	public boolean delete(Comparable key) {
		// TODO Auto-generated method stub
		return false;
	}

}
