package eg.edu.alexu.csd.filestructure.btree;

public class BTree implements IBTree {
	private IBTreeNode root = new BTreeNode();
	private int  minimumDegree;
	
	BTree(int minimumDegree){
		this.minimumDegree=  minimumDegree;
	}
	
	@Override
	public int getMinimumDegree() {		
		return this.minimumDegree;
	}

	@Override
	public IBTreeNode getRoot() {
		if (root==null)
            return null;
        return root;
	}

	@Override
	public void insert(Comparable key, Object value) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Object search(Comparable key) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean delete(Comparable key) {
		// TODO Auto-generated method stub
		return false;
	}

}
