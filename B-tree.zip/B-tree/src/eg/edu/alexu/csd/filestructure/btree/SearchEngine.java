package eg.edu.alexu.csd.filestructure.btree;

import java.util.List;

public class SearchEngine implements ISearchEngine{

	@Override
	public void indexWebPage(String filePath) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void indexDirectory(String directoryPath) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteWebPage(String filePath) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<ISearchResult> searchByWordWithRanking(String word) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<ISearchResult> searchByMultipleWordWithRanking(String sentence) {
		// TODO Auto-generated method stub
		return null;
	}

}
